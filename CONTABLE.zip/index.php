	<?php
	session_start();	
	require("conexion.php");
		
	$_SESSION['dineroT']=0;
	$_SESSION['idSemana']=0;

		
	try{
				
				$sql ="SELECT * FROM saldo";
				$resu=$base->prepare($sql);
				$resu->execute(array());
				while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
					$idSa=$consulta['id_sem'];
					$saldo=$consulta['n_saldo'];
					$idS=$consulta['id_sal'];
				}
				// Aqui se mira si ya hay semanas Ingresadas..
				if($idSa==0 ){
					header('Location:saldo.php');
				}
		
				$sql ="SELECT * FROM gasto INNER JOIN saldo ON saldo.id_sal=gasto.id_sal WHERE saldo.id_sem=$idSa ORDER BY id_gas DESC";
				$resu=$base->prepare($sql);
				$resu->execute(array());
				while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
				
					
				    $preci=$consulta['precio'];
					$_SESSION['dineroT']=$_SESSION['dineroT']+$preci;
				}
		
				$queda=$saldo-$_SESSION['dineroT'];
				
			}
			catch(Exeption $e){
				die("Error".$e->getMessage());
			}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="LIBRERIAS/bootstrap.min.css">
	
<script src="LIBRERIAS/jquery-3.2.1.min.js"></script>
<script>
	function Formulario(){
		var nombre = $("#nom").val();
		var precio = $("#pre").val();
		var idSaldo = $("#idS").val();
		
		
		if(nombre.length ==0 || precio.length ==0 || idSaldo.length ==0){
			$("#resultado").text("Datos Vacios");	
		}else{
			$.ajax({
					data: {"nombre" : nombre, "precio" : precio, "idSaldo" : idSaldo},
					url: 'INSERT/insert_gastos.php',
					type: 'post',
					beforeSend: function(){
						$("#resultado").html("Procesando, espere por favor... ");
					},
					success: function(response){
						if(response=="true"){
							$("#resultado").text("Registro Exitoso");
							window:location="index.php";
						   }else{
							  $("#resultado").text("A Ocurrido Un Error");
						   }						
					}
					
				});
		}
		
	}
</script>
<title> Gastos </title>
</head>
	
<body>
	<!-- Formulario para llenar -->
	<form action="" method="post">
		
	<div class="navbar-static-top"> <center> <header> <h1>::::::....Contable SEMANA <p><?php echo $idSa;?></p><a href="nuevaSemana.php"><img src="Imagenes/registrar.png" height="40" width="50"></a>
		<br>::::`::::::::::</h1> </header>  </center> </div>
	<div id="formulario"> <table  class="table-responsive"border="2" align="center">
		<tr>
			<th>NOMBRE PRODUCTO</th>
			<th>PRECIO</th>
			<th>CLICK</th>
		</tr>
		<tr>
			<input type="hidden"  id="idS" value="<?php echo $idS; ?>" required />
			<td><input type="text"  id="nom" required /></td>
			<td>$<input type="number" id="pre"  required /></td>
			<td><input type="button" value="ENVIAR" onClick="Formulario()" name="Enviar" class="btn-primary" /></td>
		</tr>
		
	</table>
	<div align="center" id="resultado"></div>
	</div>
		
	</form>
	<h1 align="center">.......................</h1>
	<h1 style="color:  green" align="center">....<a href="saldo.php">SALDO</a> $<?php echo($saldo); ?>..............</h1>
	<h1 align="center">.......................</h1>
	<h1 style="color: red" align="center">..<?php
		if($queda<0){
			?>
			Falta 
			<?php
			echo ($queda)-($queda+$queda);
		}else{
		?>QUEDA...$<?php echo ($queda); }?>.............</h1>
	<h1 align="center">.......................</h1>
	<h4 align="center">..........SIGUIENTE.............</h4>
	<h1 align="center">.......................</h1>
	<h4 align="center">..........CONSULTAS.............</h4>
	<h1 align="center">.......................</h1>
	
	
	<table align="center" bordercolor="#D1A521" class="table-condensed">
		
		<tr>
			<th>N° LISTA</th>
			<th>NOMBRE</th>
			<th>PRECIO</th>
			<th>FECHA Y HORA</th>
			<th>ELIMINAR</th>
		</tr>
		
		<?php
		
			try{
				$n=0;
				$sql ="SELECT * FROM gasto INNER JOIN saldo ON saldo.id_sal=gasto.id_sal  WHERE saldo.id_sem=$idSa ORDER BY id_gas DESC";
				$resu=$base->prepare($sql);
				$resu->execute(array());
				while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
					$hora = $consulta['fecha'];
					$id = $consulta['id_gas'];
					
					
					?>
						<tr>
							<td> <?php echo $n=$n+1; ?> </td>
							<td> <p style="font-size: 18px"> <?php echo $consulta['nombre'] ?> </p> </td>
							<td> <p style="font-size: 18px"> $ <?php echo $consulta['precio'] ?> </p> </td>
							<td> <p style="font-size: 18px"> <?php echo $consulta['fecha']; ?> </p> </td>
							<td> <a href="ELIMINAR/EliminarGasto.php?codi=<?php echo $id; ?>"> <img src="../MOVIL/img/eli.jpg" height="40px"> </a> </td>
						</tr>
					<?php
					
				
				}
			$_SESSION['idSemana']=$idSa;
			}
			catch(Exeption $e){
				die("Error".$e->getMessage());
			}
		
		?>
		<tr> <td colspan="4"> <p style="font-size: 23px"> TotalCompra:: <?php echo $_SESSION['dineroT'];  ?> </p> </td> </tr>			
	</table>
</body>
</html>
<?php
	
	require("../conexion.php");
	$id=$_REQUEST['codi'];
	try{
				
				$sql = "DELETE FROM gasto WHERE id_gas=$id";
				$resu=$base->prepare($sql);
				$resu->execute(array());
				$c=$resu->rowCount();
				if($c>0){
					echo 'Exitoso';
				}else{
					echo 'No elimino';
				}
				header("Location:../index.php");
			}
			catch(Exeption $e){
				die("Error".$e->getMessage());
			}
?>
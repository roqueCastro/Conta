<center>
Seguro que Quieres Eliminar el Producto 
<br>
	<a href="EliGa.php?codi=<?php echo $_REQUEST['codi'];?>"> <img src="../../MOVIL/img/bien.png" height="100px" ></a>
	<a href="../index.php"> <img src="../../MOVIL/img/mal.png" height="100px" ></a>
	<br>
	
</center>
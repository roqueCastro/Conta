<center>
Seguro que Quieres una Nueva Semana
<br>
	<a href="saldo.php?codi=<?php echo "1";?>"> <img src="../MOVIL/img/bien.png" height="100px" ></a>
	<a href="index.php"> <img src="../MOVIL/img/mal.png" height="100px" ></a>
	<br>
	<a style="text-decoration: none" href="CONSULTAS/ConsultarGastos.php"> <p style="color:green; font-size: 19;"> CONSULTA  DE GASTOS POR SEMANAS</p> </a>
</center>
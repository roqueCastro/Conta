<?php

try{

	
	
	$base= new PDO('mysql:host=localhost; dbname=contable','root','');
	$base->exec('SET CHARACTER SET utf8');
	
	

}
catch(Exection $e){
	die('error'.$e->getMessage());
}

?>
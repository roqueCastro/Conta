	<?php
	session_start();	
	require("../conexion.php");
	$saldo=0; // Guarda el saldo de la semana traido por el methodod POST
	$n=0; // Guarda el numero de la semana traido por el methodod POST
	$tPrecio=0; // sumatoria de todos los precios
	$suma=0; // Es la resta del precio con el total de precio de los articulos
	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="../LIBRERIAS/bootstrap.min.css">
	

<title> Consulta de Gastos </title>
</head>
	
<body>
	
	<header> <p align="center" style="font-size: 60px">Consultas de Gastos Por Semanas </p> </header>
	<center> <form action="" method="post">
		<select class="input-lg" name="nSemana" required>
			<option value="0">Seleccione Semana</option>
			<?php	
				try{
					
					$sql ="SELECT * FROM saldo";
					$resu=$base->prepare($sql);
					$resu->execute(array());
					while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
						echo'<option value="'.$consulta['id_sem'].'">'.'Semana'.' '.$consulta['id_sem'].'</option>';
					}
			
				}
				catch(Exeption $e){
					die("Error".$e->getMessage());
				}
			?>			
		</select>
		<input type="submit" name="envio" value="Consultar" class="input-lg">
		</form>
	</center>
	<?php 
		if(isset($_POST['envio'])){
			$n=$_POST['nSemana'];
			if($n==0){
				?>
				<script>alert('Seleccione Una Semana');</script>
				<?php
			}else if ($n>0){
				?>
				<br>
				<br>
				<center> <p style="color: darkblue; font-size: 19px">SEMANA <?php echo $n; ?></p> </center>
				<br>
	
				<table align="center" bordercolor="#D1A521" class="table-condensed">
					<tr>
						<th>Nombre</th>
						<th>Precio</th>
						<th>Fecha</th>
					</tr>
					
						<?php
						try{
				
							$sql ="SELECT * FROM gasto INNER JOIN saldo ON saldo.id_sal=gasto.id_sal WHERE saldo.id_sem=$n ORDER BY id_gas DESC";
							$resu=$base->prepare($sql);
							$resu->execute(array());
							while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
								$saldo=$consulta['n_saldo'];
								$precio=$consulta['precio'];
								?>
								<tr>
								
								<td> <?php echo $consulta['nombre']?> </td>
								<td> <?php echo $consulta['precio']?> </td>
								<td> <?php echo $consulta['fecha']?> </td>
								</tr>
								<?php
								
								$tPrecio=$tPrecio+$precio;
							}
								$suma=$saldo-$tPrecio;
						}
						catch(Exeption $e){
							die("Error".$e->getMessage());
						}
						?>
					<tr>
						<th>SALDO</th>
						<td colspan="4"> <p style="font-size: 45px"> $<?php echo $saldo; ?> </p> </td>
					</tr>
					<tr>
						<th>TOTAL QUE GASTO</th>
						<td colspan="4"> <p style="font-size: 35"> $<?php echo $tPrecio; ?> </p> </td>
					</tr>
					<tr>
						<th>DINERO QUE QUEDO</th>
						<td colspan="4"> <p style="font-size: 35"> $<?php echo $suma; ?> </p> </td>
					</tr>
				</table>
				<?php
			}
		}

	?>
</body>
</html>
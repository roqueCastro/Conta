<?php
session_start();
require('conexion.php');	

$_SESSION['semana']=1;

try{
	$sql ="SELECT * FROM saldo";
	$resu=$base->prepare($sql);
	$resu->execute(array());
	while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
		$ts=$consulta['id_sem'];
	}
		
	
}catch(Exepiton $e){
	die('error'.$e->getMessage());
}
	
	
	if(isset($_POST['envio'])){
		try{
				
				$semana=0;
				$sal=0;
				$sql ="SELECT * FROM saldo";
				$resu=$base->prepare($sql);
				$resu->execute(array());
				while($consulta=$resu->fetch(PDO::FETCH_ASSOC)){
					$semana=$consulta['id_sem'];
					$sal=$consulta['n_saldo'];
				}
		
				if($_REQUEST['codi']==1){
					echo 'vacia';
					
					try{
						$ts=$ts+1;
						$sql ="INSERT INTO saldo (n_saldo, id_sem) VALUES (:saldo, :semana)";
						$resu=$base->prepare($sql);
						$resu->execute(array(":saldo"=>$_POST['saldo'], ":semana"=>$ts));
						
						header("Location:index.php");
				
					}
					catch(Exeption $e){
						die("Error".$e->getMessage());
					}
					
					
				}else if($semana==$ts){
					echo 'llena';
					
					try{
						$sql ="UPDATE saldo SET n_saldo=:saldo WHERE id_sem=$ts";
						$resu=$base->prepare($sql);
						$resu->execute(array(":saldo"=>$_POST['saldo']));
						
						header("Location:index.php");
					}
					catch(Exeption $e){
						die("Error".$e->getMessage());
					}
					
				}
				
			}
			catch(Exeption $e){
				die("Error".$e->getMessage());
			}

	}	
?>
<h1 align="center"> INGRESA SALDO</h1>
<form action="" method="post">
	<center>
		<input type="number" style="border-color: #64CB33" value="<?php echo($sal); ?>" name="saldo">
		<input type="submit" value="Concinar" name="envio">
	</center>
	
</form>
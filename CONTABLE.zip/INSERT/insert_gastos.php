<?php
require('../conexion.php');
$nom=$_POST['nombre'];
$pre=$_POST['precio'];
$idS=$_POST['idSaldo'];
$fecha=date('Y-m-d H:i:s');

$sql ="INSERT INTO gasto (nombre,precio, fecha, id_sal)  VALUES (:n, :p, :fe, :saldo)";
	$resu=$base->prepare($sql);
	$resu->execute(array(":n"=>$nom, ":p"=>$pre, ":fe"=>$fecha, ":saldo"=>$idS));
	$contador=$resu->rowCount();
		if($contador > 0){
			echo "true";
		}else{
			echo "false";
		}


?>
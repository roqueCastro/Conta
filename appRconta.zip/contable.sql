-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-01-2018 a las 13:06:23
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `contable`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gasto`
--

CREATE TABLE `gasto` (
  `id_gas` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_sal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `gasto`
--

INSERT INTO `gasto` (`id_gas`, `nombre`, `precio`, `fecha`, `id_sal`) VALUES
(1, 'guaro', 20000, '2018-01-01 05:00:00', 2),
(2, 'memoria SD 32G', 30000, '2018-01-01 05:00:00', 2),
(3, 'recarga SIM Claro', 1000, '2018-01-01 05:00:00', 2),
(4, 'Gasolina Moto Lorena Pitaliito', 5000, '2018-01-01 05:00:00', 2),
(5, 'recarga SIM Claro', 1000, '2018-01-02 05:00:00', 2),
(6, 'Juego Sniper', 8000, '2018-01-02 05:00:00', 3),
(7, 'Mama Comida', 20000, '2018-01-15 05:00:00', 4),
(8, 'Curso Mecanica', 30000, '2018-01-15 05:00:00', 4),
(9, 'Gasolina', 5000, '2018-01-15 05:00:00', 4),
(11, 'Gel Ego', 2000, '2018-01-15 05:00:00', 4),
(12, 'Recarga ', 1000, '2018-01-15 05:00:00', 4),
(13, 'guarde ', 50000, '2018-01-15 05:00:00', 4),
(14, 'Bretaña', 2000, '2018-01-15 05:00:00', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `saldo`
--

CREATE TABLE `saldo` (
  `id_sal` int(11) NOT NULL,
  `n_saldo` int(11) NOT NULL,
  `id_sem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `saldo`
--

INSERT INTO `saldo` (`id_sal`, `n_saldo`, `id_sem`) VALUES
(2, 117000, 1),
(3, 60000, 2),
(4, 110000, 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `gasto`
--
ALTER TABLE `gasto`
  ADD PRIMARY KEY (`id_gas`),
  ADD KEY `id_sal` (`id_sal`);

--
-- Indices de la tabla `saldo`
--
ALTER TABLE `saldo`
  ADD PRIMARY KEY (`id_sal`),
  ADD KEY `id_sem` (`id_sem`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `gasto`
--
ALTER TABLE `gasto`
  MODIFY `id_gas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `saldo`
--
ALTER TABLE `saldo`
  MODIFY `id_sal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<center>
Seguro que Quieres Eliminar el Producto 
<br>
	<a href="EliGa.php?codi=<?php echo $_REQUEST['codi'];?>"> <img src="../../img/bien.png" height="100px" ></a>
	<a href="../index.php"> <img src="../../img/mal.png" height="100px" ></a>
	<br>
	
</center>